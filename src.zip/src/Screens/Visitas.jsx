import React from "react";

const Visitas = () => {
  return <div></div>;
};

export default Visitas;
