import React from "react";

const Historial = () => {
  return <div></div>;
};

export default Historial;
