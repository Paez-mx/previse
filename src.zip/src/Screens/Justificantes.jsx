import React from "react";

const Justificantes = () => {
  return <div></div>;
};

export default Justificantes;
