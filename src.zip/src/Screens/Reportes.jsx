import React from "react";

const Reportes = () => {
  return <div></div>;
};

export default Reportes;
