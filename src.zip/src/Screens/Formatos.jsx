import React from "react";

const Formatos = () => {
  return <div></div>;
};

export default Formatos;
