import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Screens/Home";
import Formatos from "./Screens/Formatos";
import Historial from "./Screens/Historial";
import Justificantes from "./Screens/Justificantes";
import Reportes from "./Screens/Reportes";
import Visitas from "./Screens/Visitas";
import logo from "./img/Logo 22.jpg";
import Sidebar from "./Components/Sidebar";
import Login from "./Screens/Login";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img
          src={logo}
          alt="School Logo"
          style={{ width: "150px", height: "150px" }}
        />
      </header>
      <Router>
        <Login />
        <Sidebar />

        <Routes>
          <Route path="/screen1" element={<Home />} />
          <Route path="/screen2" element={<Formatos />} />
          <Route path="/screen3" element={<Justificantes />} />
          <Route path="/screen4" element={<Reportes />} />
          <Route path="/screen5" element={<Visitas />} />
          <Route path="/screen6" element={<Historial />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
